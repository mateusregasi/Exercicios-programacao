import { useQuery } from "@tanstack/react-query";
import type { Produto } from "../../interfaces/Produto";

const recuperarProduto = async (id : string) : Promise<Produto> => {
  const response = await fetch("http://localhost:8080/produtos/" + id)
  if (!response.ok){
    throw new Error("Ocorreu um erro ao recuperar produtos. Status code = " + response.status)
  }
  return response.json();
}

const useRecuperarProdutoPorId = (id : string) => {
    return useQuery({
        queryKey: ['produtos', id],
        queryFn: () => recuperarProduto(id),
        staleTime: 15000
    })
}

export default useRecuperarProdutoPorId;